package com.example.data

import android.content.Context
import android.util.Log
import com.example.BuildConfig
import com.example.model.AnnouncementItem
import com.example.model.ExamType
import com.example.model.QuestionItem
import com.example.model.TestItem
import com.example.model.UserProfile
import com.example.model.UserRole
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.TimeUnit

sealed class AuthResult {
    data class Success(val user: UserProfile, val sessionToken: String) : AuthResult()
    data class Error(val message: String) : AuthResult()
}

class SupabaseRepository(private val context: Context) {

    private val sessionManager = SessionManager(context)
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    private val supabaseUrl: String
        get() = try {
            val url = BuildConfig.SUPABASE_URL
            if (url.isNotBlank() && url.startsWith("http") && !url.contains("xyzcompany")) {
                url.trimEnd('/')
            } else {
                ""
            }
        } catch (e: Exception) {
            ""
        }

    private val supabaseKey: String
        get() = try {
            val key = BuildConfig.SUPABASE_ANON_KEY
            if (key.isNotBlank() && !key.contains("dummy")) {
                key
            } else {
                ""
            }
        } catch (e: Exception) {
            ""
        }

    // In-memory synced state ensuring 0 crash & seamless local/remote reactivity
    private val localUsers = mutableListOf<UserProfile>()
    private val localTests = mutableListOf<TestItem>()
    private val localAnnouncements = mutableListOf<AnnouncementItem>()

    init {
        seedInitialData()
    }

    private fun seedInitialData() {
        // Admin user
        localUsers.add(
            UserProfile(
                id = "admin-1",
                mobile = "9999999999",
                passwordHash = "admin123",
                fullName = "Admin",
                role = UserRole.ADMIN,
                examType = null,
                isActive = true
            )
        )

        // Sample Students for each Exam Type
        localUsers.add(
            UserProfile(
                id = "student-1",
                mobile = "9876543210",
                passwordHash = "123456",
                fullName = "મનિષ",
                role = UserRole.STUDENT,
                examType = ExamType.NAVODAYA,
                isActive = true
            )
        )
        localUsers.add(
            UserProfile(
                id = "student-2",
                mobile = "9876543211",
                passwordHash = "123456",
                fullName = "રવિ",
                role = UserRole.STUDENT,
                examType = ExamType.NMMS,
                isActive = true
            )
        )
        localUsers.add(
            UserProfile(
                id = "student-3",
                mobile = "9876543212",
                passwordHash = "123456",
                fullName = "રીતા",
                role = UserRole.STUDENT,
                examType = ExamType.GYAN_SETU,
                isActive = true
            )
        )
        localUsers.add(
            UserProfile(
                id = "student-4",
                mobile = "9876543213",
                passwordHash = "123456",
                fullName = "જય",
                role = UserRole.STUDENT,
                examType = ExamType.TET_1,
                isActive = true
            )
        )
        localUsers.add(
            UserProfile(
                id = "student-5",
                mobile = "9876543214",
                passwordHash = "123456",
                fullName = "પૂજા",
                role = UserRole.STUDENT,
                examType = ExamType.GYAN_SADHANA,
                isActive = true
            )
        )

        // Seed Tests & Gujarati Questions
        seedNavodayaTests()
        seedNMMSTests()
        seedGyanSetuTests()
        seedGyanSadhanaTests()
        seedTET1Tests()

        // Seed Announcements
        seedAnnouncements()
    }

    private fun seedNavodayaTests() {
        val test1Questions = listOf(
            QuestionItem(
                id = "q_nav_1",
                testId = "nav_test_1",
                questionText = "ભારતનું રાષ્ટ્રીય પક્ષી કયું છે?",
                optionA = "મોર",
                optionB = "કબૂતર",
                optionC = "કાગડો",
                optionD = "પોપટ",
                correctOption = 0,
                explanation = "મોર ભારતનું રાષ્ટ્રીય પક્ષી છે. તેની સુંદરતા અને સાંસ્કૃતિક મહત્વને કારણે તેને રાષ્ટ્રીય પક્ષીનો દરજ્જો મળ્યો છે.",
                orderIndex = 1
            ),
            QuestionItem(
                id = "q_nav_2",
                testId = "nav_test_1",
                questionText = "ગુજરાતની સૌથી લાંબી નદી કઈ છે?",
                optionA = "તાપી",
                optionB = "નર્મદા",
                optionC = "સાબરમતી",
                optionD = "મહી",
                correctOption = 1,
                explanation = "નર્મદા નદી ગુજરાતની જીવાદોરી અને સૌથી મોટી નદી છે.",
                orderIndex = 2
            ),
            QuestionItem(
                id = "q_nav_3",
                testId = "nav_test_1",
                questionText = "સૂર્યમંડળનો સૌથી મોટો ગ્રહ કયો છે?",
                optionA = "પૃથ્વી",
                optionB = "મંગળ",
                optionC = "ગુરુ (Jupiter)",
                optionD = "શનિ",
                correctOption = 2,
                explanation = "ગુરુ ગ્રહ આપણા સૂર્યમંડળનો સૌથી મોટો ગ્રહ છે.",
                orderIndex = 3
            ),
            QuestionItem(
                id = "q_nav_4",
                testId = "nav_test_1",
                questionText = "પાંચ અંકની સૌથી નાની સંખ્યા કઈ છે?",
                optionA = "10000",
                optionB = "99999",
                optionC = "11111",
                optionD = "10001",
                correctOption = 0,
                explanation = "પાંચ અંકની સૌથી નાની સંખ્યા 10,000 છે.",
                orderIndex = 4
            ),
            QuestionItem(
                id = "q_nav_5",
                testId = "nav_test_1",
                questionText = "જો એક ચોરસની બાજુ 5 સેમી હોય, તો તેનું ક્ષેત્રફળ કેટલું થાય?",
                optionA = "20 ચો.સેમી",
                optionB = "25 ચો.સેમી",
                optionC = "10 ચો.સેમી",
                optionD = "15 ચો.સેમી",
                correctOption = 1,
                explanation = "ચોરસનું ક્ષેત્રફળ = બાજુ × બાજુ = 5 × 5 = 25 ચો.સેમી.",
                orderIndex = 5
            )
        )

        localTests.add(
            TestItem(
                id = "nav_test_1",
                examType = ExamType.NAVODAYA,
                title = "Navodaya Mock Test - 1",
                durationMinutes = 60,
                isActive = true,
                questions = test1Questions,
                createdAt = "2026-08-01"
            )
        )
        localTests.add(
            TestItem(
                id = "nav_test_2",
                examType = ExamType.NAVODAYA,
                title = "Navodaya Mock Test - 2",
                durationMinutes = 60,
                isActive = true,
                questions = test1Questions.map { it.copy(id = UUID.randomUUID().toString()) },
                createdAt = "2026-08-05"
            )
        )
        localTests.add(
            TestItem(
                id = "nav_test_3",
                examType = ExamType.NAVODAYA,
                title = "Navodaya Mock Test - 3",
                durationMinutes = 50,
                isActive = true,
                questions = test1Questions.map { it.copy(id = UUID.randomUUID().toString()) },
                createdAt = "2026-08-10"
            )
        )
        localTests.add(
            TestItem(
                id = "nav_test_4",
                examType = ExamType.NAVODAYA,
                title = "Navodaya Mock Test - 4",
                durationMinutes = 60,
                isActive = true,
                questions = test1Questions.map { it.copy(id = UUID.randomUUID().toString()) },
                createdAt = "2026-08-12"
            )
        )
    }

    private fun seedNMMSTests() {
        val nmmsQuestions = listOf(
            QuestionItem(
                id = "q_nmms_1",
                testId = "nmms_test_1",
                questionText = "માનવ શરીરમાં કેટલા હાડકાં હોય છે?",
                optionA = "206",
                optionB = "300",
                optionC = "150",
                optionD = "250",
                correctOption = 0,
                explanation = "પુખ્ત માનવ શરીરમાં સામાન્ય રીતે 206 હાડકાં હોય છે.",
                orderIndex = 1
            ),
            QuestionItem(
                id = "q_nmms_2",
                testId = "nmms_test_1",
                questionText = "શ્રેણી પૂર્ણ કરો: 2, 4, 8, 16, ___",
                optionA = "24",
                optionB = "30",
                optionC = "32",
                optionD = "64",
                correctOption = 2,
                explanation = "દરેક પદ આગળના પદથી બમણું (×2) થાય છે. 16 × 2 = 32.",
                orderIndex = 2
            ),
            QuestionItem(
                id = "q_nmms_3",
                testId = "nmms_test_1",
                questionText = "પાણીનું રાસાયણિક સૂત્ર શું છે?",
                optionA = "CO2",
                optionB = "H2O",
                optionC = "NaCl",
                optionD = "O2",
                correctOption = 1,
                explanation = "પાણીનું રાસાયણિક સૂત્ર H2O છે (2 હાઇડ્રોજન + 1 ઓક્સિજન).",
                orderIndex = 3
            )
        )

        localTests.add(
            TestItem(
                id = "nmms_test_1",
                examType = ExamType.NMMS,
                title = "NMMS MAT Mock Test - 1",
                durationMinutes = 45,
                isActive = true,
                questions = nmmsQuestions,
                createdAt = "2026-08-02"
            )
        )
        localTests.add(
            TestItem(
                id = "nmms_test_2",
                examType = ExamType.NMMS,
                title = "NMMS SAT Mock Test - 2",
                durationMinutes = 45,
                isActive = true,
                questions = nmmsQuestions.map { it.copy(id = UUID.randomUUID().toString()) },
                createdAt = "2026-08-06"
            )
        )
    }

    private fun seedGyanSetuTests() {
        val gsQuestions = listOf(
            QuestionItem(
                id = "q_gs_1",
                testId = "gs_test_1",
                questionText = "જ્ઞાન સેતુ પરીક્ષા કોના માટે યોજાય છે?",
                optionA = "પ્રાથમિક શાળાના તેજસ્વી વિદ્યાર્થીઓ માટે",
                optionB = "કોલેજ વિદ્યાર્થીઓ માટે",
                optionC = "શિક્ષકો માટે",
                optionD = "માત્ર રમતગમત માટે",
                correctOption = 0,
                explanation = "જ્ઞાન સેતુ સ્કોલરશીપ પરીક્ષા તેજસ્વી વિદ્યાર્થીઓને શિક્ષણમાં સહાય માટે યોજાય છે.",
                orderIndex = 1
            ),
            QuestionItem(
                id = "q_gs_2",
                testId = "gs_test_1",
                questionText = "1 કિલોગ્રામ એટલે કેટલા ગ્રામ થાય?",
                optionA = "100 ગ્રામ",
                optionB = "500 ગ્રામ",
                optionC = "1000 ગ્રામ",
                optionD = "10000 ગ્રામ",
                correctOption = 2,
                explanation = "1 કિલોગ્રામ (kg) = 1000 ગ્રામ (g).",
                orderIndex = 2
            )
        )

        localTests.add(
            TestItem(
                id = "gs_test_1",
                examType = ExamType.GYAN_SETU,
                title = "Gyan Setu Practice Test - 1",
                durationMinutes = 40,
                isActive = true,
                questions = gsQuestions,
                createdAt = "2026-08-03"
            )
        )
        localTests.add(
            TestItem(
                id = "gs_test_2",
                examType = ExamType.GYAN_SETU,
                title = "Gyan Setu Practice Test - 2",
                durationMinutes = 40,
                isActive = true,
                questions = gsQuestions.map { it.copy(id = UUID.randomUUID().toString()) },
                createdAt = "2026-08-08"
            )
        )
    }

    private fun seedGyanSadhanaTests() {
        val gsdQuestions = listOf(
            QuestionItem(
                id = "q_gsd_1",
                testId = "gsd_test_1",
                questionText = "ગુજરાતનું પાટનગર કયું છે?",
                optionA = "અમદાવાદ",
                optionB = "ગાંધીનગર",
                optionC = "સુરત",
                optionD = "રાજકોટ",
                correctOption = 1,
                explanation = "ગુજરાતનું પાટનગર ગાંધીનગર છે.",
                orderIndex = 1
            ),
            QuestionItem(
                id = "q_gsd_2",
                testId = "gsd_test_1",
                questionText = "વૃક્ષો દિવસ દરમિયાન કયો વાયુ મુક્ત કરે છે?",
                optionA = "ઓક્સિજન",
                optionB = "કાર્બન ડાયોક્સાઇડ",
                optionC = "નાઇટ્રોજન",
                optionD = "મિથેન",
                correctOption = 0,
                explanation = "પ્રકાશસંશ્લેષણ ક્રિયા દ્વારા વનસ્પતિ દિવસ દરમિયાન ઓક્સિજન વાયુ મુક્ત કરે છે.",
                orderIndex = 2
            )
        )

        localTests.add(
            TestItem(
                id = "gsd_test_1",
                examType = ExamType.GYAN_SADHANA,
                title = "Gyan Sadhana Mock Test - 1",
                durationMinutes = 45,
                isActive = true,
                questions = gsdQuestions,
                createdAt = "2026-08-04"
            )
        )
    }

    private fun seedTET1Tests() {
        val tetQuestions = listOf(
            QuestionItem(
                id = "q_tet_1",
                testId = "tet_test_1",
                questionText = "બાળ વિકાસ અને શિક્ષણના સિદ્ધાંતોમાં 'જીન પિયાજે' શેના માટે પ્રખ્યાત છે?",
                optionA = "જ્ઞાનાત્મક વિકાસનો સિદ્ધાંત (Cognitive Development)",
                optionB = "મનોવિશ્લેષણવાદ",
                optionC = "વર્તનવાદ",
                optionD = "ભાષા વિકાસ",
                correctOption = 0,
                explanation = "જીન પિયાજેએ બાળકના જ્ઞાનાત્મક (બોધાત્મક) વિકાસના ચાર તબક્કા દર્શાવ્યા છે.",
                orderIndex = 1
            ),
            QuestionItem(
                id = "q_tet_2",
                testId = "tet_test_1",
                questionText = "ગુજરાતી ભાષાનું પ્રથમ વ્યાકરણ પુસ્તક કોણે લખ્યું હતું?",
                optionA = "નર્મદ",
                optionB = "હેમચંદ્રાચાર્ય (સિદ્ધહેમ શબ્દાનુશાસન)",
                optionC = "દલપતરામ",
                optionD = "કાકા કાલેલકર",
                correctOption = 1,
                explanation = "કલિકાલસર્વજ્ઞ હેમચંદ્રાચાર્યજીએ 'સિદ્ધહેમ શબ્દાનુશાસન' વ્યાકરણ ગ્રંથની રચના કરી હતી.",
                orderIndex = 2
            ),
            QuestionItem(
                id = "q_tet_3",
                testId = "tet_test_1",
                questionText = "RTE એક્ટ 2009 મુજબ કેટલા વર્ષ સુધીના બાળકોને મફત અને ફરજિયાત શિક્ષણનો અધિકાર છે?",
                optionA = "6 થી 14 વર્ષ",
                optionB = "5 થી 12 વર્ષ",
                optionC = "7 થી 15 વર્ષ",
                optionD = "3 થી 10 વર્ષ",
                correctOption = 0,
                explanation = "RTE એક્ટ 2009 અંતર્ગત 6 થી 14 વર્ષના તમામ બાળકો માટે પ્રાથમિક શિક્ષણ મફત અને ફરજિયાત છે.",
                orderIndex = 3
            )
        )

        localTests.add(
            TestItem(
                id = "tet_test_1",
                examType = ExamType.TET_1,
                title = "TET-1 Full Mock Test - 1",
                durationMinutes = 60,
                isActive = true,
                questions = tetQuestions,
                createdAt = "2026-08-01"
            )
        )
        localTests.add(
            TestItem(
                id = "tet_test_2",
                examType = ExamType.TET_1,
                title = "TET-1 બાળ વિકાસ અને મનોવિજ્ઞાન Test - 2",
                durationMinutes = 45,
                isActive = true,
                questions = tetQuestions.map { it.copy(id = UUID.randomUUID().toString()) },
                createdAt = "2026-08-07"
            )
        )
    }

    private fun seedAnnouncements() {
        localAnnouncements.add(
            AnnouncementItem(
                id = "ann_1",
                title = "નવોદય Mock Test - 2 ની જાહેરાત",
                message = "નવોદય Mock Test - 2 આવતીકાલે સવારે 10:00 વાગ્યે શરૂ થશે. તમામ વિદ્યાર્થીઓએ સમયસર ટેસ્ટ આપવો.",
                examType = ExamType.NAVODAYA,
                date = "14/05/2026",
                isActive = true,
                isImportant = true
            )
        )
        localAnnouncements.add(
            AnnouncementItem(
                id = "ann_2",
                title = "નવા ટેસ્ટ અપલોડ થયા છે",
                message = "નવોદય Previous Year આધારિત નવા ટેસ્ટ વિભાગમાં ઉમેરાયેલ છે.",
                examType = ExamType.NAVODAYA,
                date = "12/05/2026",
                isActive = true,
                isImportant = false
            )
        )
        localAnnouncements.add(
            AnnouncementItem(
                id = "ann_3",
                title = "NMMS વિદ્યાર્થીઓ માટે ખાસ સૂચના",
                message = "NMMS મેટ (માનસિક ક્ષમતા કસોટી) ની નવી પ્રેક્ટિસ ટેસ્ટ ઉપલબ્ધ થઈ ગઈ છે.",
                examType = ExamType.NMMS,
                date = "10/05/2026",
                isActive = true,
                isImportant = true
            )
        )
        localAnnouncements.add(
            AnnouncementItem(
                id = "ann_4",
                title = "TET-1 પેડાગોજી પ્રશ્નોત્તરી",
                message = "TET-1 માટે બાળ વિકાસ અને શિક્ષણ પદ્ધતિના મહત્વના પ્રશ્નો તૈયાર કરવામાં આવ્યા છે.",
                examType = ExamType.TET_1,
                date = "11/05/2026",
                isActive = true,
                isImportant = false
            )
        )
    }

    // --- Authentication Operations ---

    suspend fun login(mobile: String, password: String): AuthResult = withContext(Dispatchers.IO) {
        val trimmedMobile = mobile.trim()
        val trimmedPassword = password.trim()

        if (trimmedMobile.isEmpty() || trimmedPassword.isEmpty()) {
            return@withContext AuthResult.Error("કૃપા કરીને મોબાઇલ નંબર અને પાસવર્ડ દાખલ કરો.")
        }

        // Try Supabase API if configured
        if (supabaseUrl.isNotBlank() && supabaseKey.isNotBlank()) {
            try {
                val url = "$supabaseUrl/rest/v1/profiles?mobile=eq.$trimmedMobile&select=*"
                val request = Request.Builder()
                    .url(url)
                    .addHeader("apikey", supabaseKey)
                    .addHeader("Authorization", "Bearer $supabaseKey")
                    .get()
                    .build()

                val response = client.newCall(request).execute()
                if (response.isSuccessful) {
                    val responseBody = response.body?.string() ?: ""
                    val jsonArray = JSONArray(responseBody)
                    if (jsonArray.length() > 0) {
                        val userObj = jsonArray.getJSONObject(0)
                        val isActive = userObj.optBoolean("is_active", true)
                        if (!isActive) {
                            return@withContext AuthResult.Error("આ એકાઉન્ટ ઉપલબ્ધ નથી.")
                        }

                        val storedPassword = userObj.optString("password_hash", "")
                        if (storedPassword != trimmedPassword) {
                            return@withContext AuthResult.Error("મોબાઇલ નંબર અથવા પાસવર્ડ ખોટો છે.")
                        }

                        val sessionToken = UUID.randomUUID().toString()
                        val userProfile = UserProfile(
                            id = userObj.optString("id", UUID.randomUUID().toString()),
                            mobile = userObj.optString("mobile", trimmedMobile),
                            passwordHash = storedPassword,
                            fullName = userObj.optString("full_name", "User"),
                            role = UserRole.fromString(userObj.optString("role", "student")),
                            examType = if (userObj.has("exam_type") && !userObj.isNull("exam_type")) {
                                ExamType.fromString(userObj.getString("exam_type"))
                            } else null,
                            isActive = true,
                            sessionToken = sessionToken
                        )

                        // Update session token on Supabase
                        updateRemoteSessionToken(userProfile.id, sessionToken)
                        sessionManager.saveUserSession(userProfile, sessionToken)
                        return@withContext AuthResult.Success(userProfile, sessionToken)
                    }
                }
            } catch (e: Exception) {
                Log.e("SupabaseRepo", "Supabase login exception: ${e.message}")
            }
        }

        // Check local users list
        val user = localUsers.firstOrNull { it.mobile == trimmedMobile }
        if (user == null) {
            return@withContext AuthResult.Error("મોબાઇલ નંબર અથવા પાસવર્ડ ખોટો છે.")
        }

        if (!user.isActive) {
            return@withContext AuthResult.Error("આ એકાઉન્ટ ઉપલબ્ધ નથી.")
        }

        if (user.passwordHash != trimmedPassword) {
            return@withContext AuthResult.Error("મોબાઇલ નંબર અથવા પાસવર્ડ ખોટો છે.")
        }

        val sessionToken = UUID.randomUUID().toString()
        val activeUser = user.copy(sessionToken = sessionToken)
        
        // Update local session
        val index = localUsers.indexOfFirst { it.id == user.id }
        if (index != -1) {
            localUsers[index] = activeUser
        }

        sessionManager.saveUserSession(activeUser, sessionToken)
        AuthResult.Success(activeUser, sessionToken)
    }

    private fun updateRemoteSessionToken(userId: String, token: String) {
        try {
            if (supabaseUrl.isBlank() || supabaseKey.isBlank()) return
            val url = "$supabaseUrl/rest/v1/profiles?id=eq.$userId"
            val json = JSONObject().put("session_token", token)
            val body = json.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url(url)
                .addHeader("apikey", supabaseKey)
                .addHeader("Authorization", "Bearer $supabaseKey")
                .patch(body)
                .build()
            client.newCall(request).execute()
        } catch (e: Exception) {
            Log.e("SupabaseRepo", "Update session error: ${e.message}")
        }
    }

    fun getActiveSession(): UserProfile? {
        val user = sessionManager.getLoggedInUser() ?: return null
        val localUser = localUsers.firstOrNull { it.id == user.id }
        if (localUser != null && !localUser.isActive) {
            sessionManager.clearSession()
            return null
        }
        return localUser ?: user
    }

    fun logout() {
        sessionManager.clearSession()
    }

    // --- Student Features ---

    suspend fun getTestsForStudent(examType: ExamType): List<TestItem> = withContext(Dispatchers.IO) {
        // Strict filtering: ONLY student's assigned Exam Type AND ONLY Active tests
        try {
            if (supabaseUrl.isNotBlank() && supabaseKey.isNotBlank()) {
                val url = "$supabaseUrl/rest/v1/tests?exam_type=eq.${examType.id}&is_active=eq.true&select=*,questions(*)"
                val request = Request.Builder()
                    .url(url)
                    .addHeader("apikey", supabaseKey)
                    .addHeader("Authorization", "Bearer $supabaseKey")
                    .get()
                    .build()
                val response = client.newCall(request).execute()
                if (response.isSuccessful) {
                    val body = response.body?.string() ?: ""
                    val array = JSONArray(body)
                    if (array.length() > 0) {
                        val tests = mutableListOf<TestItem>()
                        for (i in 0 until array.length()) {
                            val obj = array.getJSONObject(i)
                            val qArray = obj.optJSONArray("questions") ?: JSONArray()
                            val qList = mutableListOf<QuestionItem>()
                            for (j in 0 until qArray.length()) {
                                val qObj = qArray.getJSONObject(j)
                                qList.add(
                                    QuestionItem(
                                        id = qObj.optString("id", UUID.randomUUID().toString()),
                                        testId = qObj.optString("test_id", ""),
                                        questionText = qObj.optString("question_text", ""),
                                        optionA = qObj.optString("option_a", ""),
                                        optionB = qObj.optString("option_b", ""),
                                        optionC = qObj.optString("option_c", ""),
                                        optionD = qObj.optString("option_d", ""),
                                        correctOption = qObj.optInt("correct_option", 0),
                                        explanation = qObj.optString("explanation", ""),
                                        orderIndex = qObj.optInt("order_index", j + 1)
                                    )
                                )
                            }
                            tests.add(
                                TestItem(
                                    id = obj.optString("id", UUID.randomUUID().toString()),
                                    examType = examType,
                                    title = obj.optString("title", ""),
                                    durationMinutes = obj.optInt("duration_minutes", 30),
                                    isActive = true,
                                    questions = qList,
                                    createdAt = obj.optString("created_at", "")
                                )
                            )
                        }
                        return@withContext tests
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("SupabaseRepo", "Get tests error: ${e.message}")
        }

        // Return from local list strictly active & matched exam type
        localTests.filter { it.examType == examType && it.isActive }
    }

    suspend fun getTestById(testId: String, studentExamType: ExamType?): TestItem? = withContext(Dispatchers.IO) {
        val test = localTests.firstOrNull { it.id == testId } ?: return@withContext null
        // If student role, ensure exam type matches AND test is active
        if (studentExamType != null) {
            if (test.examType != studentExamType || !test.isActive) {
                return@withContext null
            }
        }
        test
    }

    suspend fun getAnnouncementsForStudent(examType: ExamType): List<AnnouncementItem> = withContext(Dispatchers.IO) {
        localAnnouncements.filter { it.examType == examType && it.isActive }
    }

    // --- Admin Operations ---

    suspend fun getAllStudents(): List<UserProfile> = withContext(Dispatchers.IO) {
        localUsers.filter { it.role == UserRole.STUDENT }
    }

    suspend fun addStudent(
        fullName: String,
        mobile: String,
        password: String,
        examType: ExamType,
        isActive: Boolean = true
    ): Boolean = withContext(Dispatchers.IO) {
        val existing = localUsers.firstOrNull { it.mobile == mobile }
        if (existing != null) {
            // Update existing if present
            val index = localUsers.indexOf(existing)
            localUsers[index] = existing.copy(
                fullName = fullName,
                passwordHash = password,
                examType = examType,
                isActive = isActive
            )
            return@withContext true
        }

        val newStudent = UserProfile(
            id = UUID.randomUUID().toString(),
            mobile = mobile,
            passwordHash = password,
            fullName = fullName,
            role = UserRole.STUDENT,
            examType = examType,
            isActive = isActive,
            createdAt = "2026-08-13"
        )
        localUsers.add(newStudent)

        // Sync to Supabase if configured
        try {
            if (supabaseUrl.isNotBlank() && supabaseKey.isNotBlank()) {
                val url = "$supabaseUrl/rest/v1/profiles"
                val json = JSONObject().apply {
                    put("id", newStudent.id)
                    put("mobile", newStudent.mobile)
                    put("password_hash", newStudent.passwordHash)
                    put("full_name", newStudent.fullName)
                    put("role", "student")
                    put("exam_type", newStudent.examType?.id)
                    put("is_active", newStudent.isActive)
                }
                val body = json.toString().toRequestBody("application/json".toMediaType())
                val request = Request.Builder()
                    .url(url)
                    .addHeader("apikey", supabaseKey)
                    .addHeader("Authorization", "Bearer $supabaseKey")
                    .post(body)
                    .build()
                client.newCall(request).execute()
            }
        } catch (e: Exception) {
            Log.e("SupabaseRepo", "Add student remote error: ${e.message}")
        }
        true
    }

    suspend fun updateStudent(
        id: String,
        fullName: String,
        mobile: String,
        password: String,
        examType: ExamType,
        isActive: Boolean
    ): Boolean = withContext(Dispatchers.IO) {
        val index = localUsers.indexOfFirst { it.id == id }
        if (index != -1) {
            val old = localUsers[index]
            val updated = old.copy(
                fullName = fullName,
                mobile = mobile,
                passwordHash = if (password.isNotBlank()) password else old.passwordHash,
                examType = examType,
                isActive = isActive
            )
            localUsers[index] = updated

            // Invalidate session if blocked
            if (!isActive && sessionManager.getLoggedInUser()?.id == id) {
                sessionManager.clearSession()
            }
            return@withContext true
        }
        false
    }

    suspend fun deleteStudent(id: String): Boolean = withContext(Dispatchers.IO) {
        // Complete block & deletion
        val index = localUsers.indexOfFirst { it.id == id }
        if (index != -1) {
            localUsers.removeAt(index)
            // If active user is deleted, clear session
            if (sessionManager.getLoggedInUser()?.id == id) {
                sessionManager.clearSession()
            }
        }

        try {
            if (supabaseUrl.isNotBlank() && supabaseKey.isNotBlank()) {
                val url = "$supabaseUrl/rest/v1/profiles?id=eq.$id"
                val request = Request.Builder()
                    .url(url)
                    .addHeader("apikey", supabaseKey)
                    .addHeader("Authorization", "Bearer $supabaseKey")
                    .delete()
                    .build()
                client.newCall(request).execute()
            }
        } catch (e: Exception) {
            Log.e("SupabaseRepo", "Delete student remote error: ${e.message}")
        }
        true
    }

    suspend fun getAllTestsForAdmin(examTypeFilter: ExamType? = null): List<TestItem> = withContext(Dispatchers.IO) {
        if (examTypeFilter != null) {
            localTests.filter { it.examType == examTypeFilter }
        } else {
            localTests
        }
    }

    suspend fun toggleTestStatus(testId: String, isActive: Boolean): Boolean = withContext(Dispatchers.IO) {
        val index = localTests.indexOfFirst { it.id == testId }
        if (index != -1) {
            val old = localTests[index]
            localTests[index] = old.copy(isActive = isActive)
            return@withContext true
        }
        false
    }

    suspend fun addOrUpdateTest(test: TestItem): Boolean = withContext(Dispatchers.IO) {
        val index = localTests.indexOfFirst { it.id == test.id }
        if (index != -1) {
            localTests[index] = test
        } else {
            localTests.add(0, test)
        }
        true
    }

    suspend fun deleteTest(testId: String): Boolean = withContext(Dispatchers.IO) {
        localTests.removeAll { it.id == testId }
    }

    suspend fun getAllAnnouncementsForAdmin(examTypeFilter: ExamType? = null): List<AnnouncementItem> = withContext(Dispatchers.IO) {
        if (examTypeFilter != null) {
            localAnnouncements.filter { it.examType == examTypeFilter }
        } else {
            localAnnouncements
        }
    }

    suspend fun addOrUpdateAnnouncement(item: AnnouncementItem): Boolean = withContext(Dispatchers.IO) {
        val index = localAnnouncements.indexOfFirst { it.id == item.id }
        if (index != -1) {
            localAnnouncements[index] = item
        } else {
            localAnnouncements.add(0, item)
        }
        true
    }

    suspend fun deleteAnnouncement(id: String): Boolean = withContext(Dispatchers.IO) {
        localAnnouncements.removeAll { it.id == id }
    }
}
