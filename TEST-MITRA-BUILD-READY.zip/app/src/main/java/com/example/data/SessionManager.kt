package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.model.ExamType
import com.example.model.UserProfile
import com.example.model.UserRole
import java.util.UUID

class SessionManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("test_mitra_session", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_IS_LOGGED_IN = "is_logged_in"
        private const val KEY_USER_ID = "user_id"
        private const val KEY_MOBILE = "user_mobile"
        private const val KEY_FULL_NAME = "user_full_name"
        private const val KEY_ROLE = "user_role"
        private const val KEY_EXAM_TYPE = "user_exam_type"
        private const val KEY_SESSION_TOKEN = "session_token"
    }

    fun saveUserSession(user: UserProfile, newSessionToken: String = UUID.randomUUID().toString()) {
        prefs.edit().apply {
            putBoolean(KEY_IS_LOGGED_IN, true)
            putString(KEY_USER_ID, user.id)
            putString(KEY_MOBILE, user.mobile)
            putString(KEY_FULL_NAME, user.fullName)
            putString(KEY_ROLE, user.role.name)
            putString(KEY_EXAM_TYPE, user.examType?.id)
            putString(KEY_SESSION_TOKEN, newSessionToken)
            apply()
        }
    }

    fun getLoggedInUser(): UserProfile? {
        val isLoggedIn = prefs.getBoolean(KEY_IS_LOGGED_IN, false)
        if (!isLoggedIn) return null

        val id = prefs.getString(KEY_USER_ID, null) ?: return null
        val mobile = prefs.getString(KEY_MOBILE, "") ?: ""
        val fullName = prefs.getString(KEY_FULL_NAME, "") ?: ""
        val roleStr = prefs.getString(KEY_ROLE, UserRole.STUDENT.name)
        val role = UserRole.fromString(roleStr)
        val examTypeStr = prefs.getString(KEY_EXAM_TYPE, null)
        val examType = examTypeStr?.let { ExamType.fromString(it) }
        val sessionToken = prefs.getString(KEY_SESSION_TOKEN, null)

        return UserProfile(
            id = id,
            mobile = mobile,
            passwordHash = "",
            fullName = fullName,
            role = role,
            examType = examType,
            isActive = true,
            sessionToken = sessionToken
        )
    }

    fun getSessionToken(): String? {
        return prefs.getString(KEY_SESSION_TOKEN, null)
    }

    fun clearSession() {
        prefs.edit().clear().apply()
    }
}
