package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.AnnouncementItem
import com.example.model.ExamType
import com.example.model.QuestionItem
import com.example.model.TestItem
import com.example.model.UserProfile
import com.example.model.UserRole
import com.example.ui.theme.*
import com.example.viewmodel.AdminSection
import com.example.viewmodel.UiState
import java.util.UUID

@Composable
fun AdminDashboardScreen(
    state: UiState,
    onNavigateSection: (AdminSection) -> Unit,
    onSetExamFilter: (ExamType?) -> Unit,
    onSearchStudents: (String) -> Unit,
    onAddStudent: (String, String, String, ExamType, Boolean) -> Unit,
    onUpdateStudent: (String, String, String, String, ExamType, Boolean) -> Unit,
    onDeleteStudent: (String) -> Unit,
    onToggleTestStatus: (String, Boolean) -> Unit,
    onSaveTest: (TestItem) -> Unit,
    onDeleteTest: (String) -> Unit,
    onSaveAnnouncement: (AnnouncementItem) -> Unit,
    onDeleteAnnouncement: (String) -> Unit,
    onLogout: () -> Unit
) {
    when (state.adminCurrentSection) {
        AdminSection.MAIN_MENU -> AdminMainMenu(
            adminUser = state.currentUser,
            onNavigate = onNavigateSection,
            onLogout = onLogout
        )
        AdminSection.STUDENT_MANAGEMENT -> AdminStudentManagementScreen(
            students = state.adminStudents,
            searchQuery = state.adminStudentSearchQuery,
            onSearchQueryChange = onSearchStudents,
            onAddStudent = onAddStudent,
            onUpdateStudent = onUpdateStudent,
            onDeleteStudent = onDeleteStudent,
            onBack = { onNavigateSection(AdminSection.MAIN_MENU) }
        )
        AdminSection.TEST_MANAGEMENT -> AdminTestManagementScreen(
            tests = state.adminTests,
            selectedExamFilter = state.adminSelectedExamFilter,
            onExamFilterSelected = onSetExamFilter,
            onToggleTestStatus = onToggleTestStatus,
            onSaveTest = onSaveTest,
            onDeleteTest = onDeleteTest,
            onBack = { onNavigateSection(AdminSection.MAIN_MENU) }
        )
        AdminSection.EXAM_TYPE_MANAGEMENT -> AdminExamTypeManagementScreen(
            tests = state.adminTests,
            students = state.adminStudents,
            onSelectExam = { exam ->
                onSetExamFilter(exam)
                onNavigateSection(AdminSection.TEST_MANAGEMENT)
            },
            onBack = { onNavigateSection(AdminSection.MAIN_MENU) }
        )
        AdminSection.ANNOUNCEMENT_MANAGEMENT -> AdminAnnouncementManagementScreen(
            announcements = state.adminAnnouncements,
            selectedExamFilter = state.adminSelectedExamFilter,
            onExamFilterSelected = onSetExamFilter,
            onSaveAnnouncement = onSaveAnnouncement,
            onDeleteAnnouncement = onDeleteAnnouncement,
            onBack = { onNavigateSection(AdminSection.MAIN_MENU) }
        )
        AdminSection.ADMIN_PROFILE -> AdminProfileScreen(
            adminUser = state.currentUser,
            onLogout = onLogout,
            onBack = { onNavigateSection(AdminSection.MAIN_MENU) }
        )
    }
}

// --- Admin Main Menu Dashboard ---

@Composable
fun AdminMainMenu(
    adminUser: UserProfile?,
    onNavigate: (AdminSection) -> Unit,
    onLogout: () -> Unit
) {
    var showLogoutDialog by remember { mutableStateOf(false) }

    if (showLogoutDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutDialog = false },
            title = { Text("લૉગઆઉટ", fontWeight = FontWeight.Bold) },
            text = { Text("શું તમે એડમિન મોડમાંથી લૉગઆઉટ કરવા માંગો છો?") },
            confirmButton = {
                Button(
                    onClick = {
                        showLogoutDialog = false
                        onLogout()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TestMitraRed)
                ) {
                    Text("લૉગઆઉટ")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showLogoutDialog = false }) {
                    Text("રદ કરો")
                }
            }
        )
    }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "હેલો, Admin 👋",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "TEST MITRA કંટ્રોલ પેનલ",
                        fontSize = 13.sp,
                        color = TextSecondary
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFE3F2FD))
                            .clickable { onNavigate(AdminSection.ADMIN_PROFILE) },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = "Admin Profile",
                            tint = TestMitraBlue,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(BackgroundLight)
                .padding(innerPadding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text(
                text = "એડમિન મેનેજમેન્ટ",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            // 2x2 Grid of Management Cards matching mockup
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                AdminDashboardCard(
                    title = "વિદ્યાર્થી મેનેજમેન્ટ",
                    subtitle = "વિદ્યાર્થીઓ ઉમેરો / મેનેજ કરો",
                    icon = Icons.Default.Groups,
                    iconBgColor = Color(0xFFE3F2FD),
                    iconTint = TestMitraBlue,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigate(AdminSection.STUDENT_MANAGEMENT) }
                )
                AdminDashboardCard(
                    title = "ટેસ્ટ મેનેજમેન્ટ",
                    subtitle = "ટેસ્ટ બનાવો / એક્ટિવ કરો",
                    icon = Icons.Default.Quiz,
                    iconBgColor = Color(0xFFE8F5E9),
                    iconTint = TestMitraGreen,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigate(AdminSection.TEST_MANAGEMENT) }
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                AdminDashboardCard(
                    title = "પરીક્ષા પ્રકાર",
                    subtitle = "બધા 5 પરીક્ષા વિભાગો",
                    icon = Icons.Default.Category,
                    iconBgColor = Color(0xFFEDE7F6),
                    iconTint = Color(0xFF5E35B1),
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigate(AdminSection.EXAM_TYPE_MANAGEMENT) }
                )
                AdminDashboardCard(
                    title = "સૂચનાઓ મેનેજમેન્ટ",
                    subtitle = "નોટિફિકેશન મોકલો",
                    icon = Icons.Default.Campaign,
                    iconBgColor = Color(0xFFFFF3E0),
                    iconTint = TestMitraOrange,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigate(AdminSection.ANNOUNCEMENT_MANAGEMENT) }
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Bottom Action Row (Profile & Logout)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onNavigate(AdminSection.ADMIN_PROFILE) }
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Person, contentDescription = null, tint = TestMitraBlue)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("પ્રોફાઇલ", fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                    }
                }

                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE)),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { showLogoutDialog = true }
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = null, tint = TestMitraRed)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("લૉગઆઉટ", fontWeight = FontWeight.SemiBold, fontSize = 15.sp, color = TestMitraRed)
                    }
                }
            }
        }
    }
}

@Composable
fun AdminDashboardCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    iconBgColor: Color,
    iconTint: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, BorderLight),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        modifier = modifier
            .height(140.dp)
            .clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(iconBgColor),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(24.dp)
                )
            }

            Column {
                Text(
                    text = title,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = subtitle,
                    fontSize = 12.sp,
                    color = TextSecondary
                )
            }
        }
    }
}

// --- Admin Student Management Screen ---

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminStudentManagementScreen(
    students: List<UserProfile>,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    onAddStudent: (String, String, String, ExamType, Boolean) -> Unit,
    onUpdateStudent: (String, String, String, String, ExamType, Boolean) -> Unit,
    onDeleteStudent: (String) -> Unit,
    onBack: () -> Unit
) {
    var showAddEditDialog by remember { mutableStateOf(false) }
    var editingStudent by remember { mutableStateOf<UserProfile?>(null) }
    var studentToDelete by remember { mutableStateOf<UserProfile?>(null) }

    val filteredStudents = students.filter {
        it.fullName.contains(searchQuery, ignoreCase = true) ||
                it.mobile.contains(searchQuery) ||
                (it.examType?.displayNameGujarati?.contains(searchQuery, ignoreCase = true) == true)
    }

    // Add / Edit Student Dialog
    if (showAddEditDialog) {
        StudentAddEditDialog(
            student = editingStudent,
            onDismiss = {
                showAddEditDialog = false
                editingStudent = null
            },
            onSave = { name, mobile, pass, examType, isActive ->
                if (editingStudent == null) {
                    onAddStudent(name, mobile, pass, examType, isActive)
                } else {
                    onUpdateStudent(editingStudent!!.id, name, mobile, pass, examType, isActive)
                }
                showAddEditDialog = false
                editingStudent = null
            }
        )
    }

    // Student Delete Dialog with Strict Warning
    if (studentToDelete != null) {
        AlertDialog(
            onDismissRequest = { studentToDelete = null },
            icon = {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = null,
                    tint = TestMitraRed,
                    modifier = Modifier.size(40.dp)
                )
            },
            title = {
                Text(
                    text = "ચેતવણી!",
                    fontWeight = FontWeight.Bold,
                    color = TestMitraRed,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "નામ: ${studentToDelete?.fullName}\nમોબાઇલ: ${studentToDelete?.mobile}\nપરીક્ષા પ્રકાર: ${studentToDelete?.examType?.displayNameGujarati}",
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Delete કર્યા બાદ આ વિદ્યાર્થી ફરી Login કરી શકશે નહીં.",
                        color = TestMitraRed,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val id = studentToDelete?.id
                        if (id != null) {
                            onDeleteStudent(id)
                        }
                        studentToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TestMitraRed),
                    modifier = Modifier.testTag("confirm_delete_student_button")
                ) {
                    Text("Delete કરો")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { studentToDelete = null }) {
                    Text("રદ કરો")
                }
            }
        )
    }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "પાછળ")
                }
                Text(
                    text = "વિદ્યાર્થી યાદી",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }
        },
        floatingActionButton = {
            Button(
                onClick = {
                    editingStudent = null
                    showAddEditDialog = true
                },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = TestMitraBlue),
                modifier = Modifier
                    .padding(16.dp)
                    .testTag("add_new_student_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("+ નવો વિદ્યાર્થી", fontWeight = FontWeight.Bold)
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(BackgroundLight)
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            // Search Field
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchQueryChange,
                placeholder = { Text("વિદ્યાર્થી શોધો...", color = Color(0xFF9E9E9E)) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TestMitraBlue) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchQueryChange("") }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = TestMitraBlue,
                    unfocusedBorderColor = BorderLight,
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White
                ),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            if (filteredStudents.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "કોઈ વિદ્યાર્થી મળ્યો નથી.",
                        color = TextSecondary,
                        fontSize = 16.sp
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f)
                ) {
                    items(filteredStudents) { student ->
                        AdminStudentCard(
                            student = student,
                            onEdit = {
                                editingStudent = student
                                showAddEditDialog = true
                            },
                            onDelete = {
                                studentToDelete = student
                            }
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun AdminStudentCard(
    student: UserProfile,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val examColor = getExamColor(student.examType ?: ExamType.NAVODAYA)

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, BorderLight),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(TestMitraSkySubtle),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = null,
                        tint = TestMitraBlue,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = student.fullName,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = student.mobile,
                        fontSize = 13.sp,
                        color = TextSecondary
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                // Exam Badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(examColor.copy(alpha = 0.12f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = student.examType?.englishName ?: "None",
                        color = examColor,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Edit Button
                IconButton(onClick = onEdit, modifier = Modifier.size(36.dp)) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "Edit",
                        tint = TestMitraGreen,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Delete Button
                IconButton(onClick = onDelete, modifier = Modifier.size(36.dp)) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Delete",
                        tint = TestMitraRed,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

// --- Add / Edit Student Dialog ---

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentAddEditDialog(
    student: UserProfile?,
    onDismiss: () -> Unit,
    onSave: (name: String, mobile: String, password: String, examType: ExamType, isActive: Boolean) -> Unit
) {
    var name by remember { mutableStateOf(student?.fullName ?: "") }
    var mobile by remember { mutableStateOf(student?.mobile ?: "") }
    var password by remember { mutableStateOf(if (student != null) "" else "123456") }
    var isPassVisible by remember { mutableStateOf(false) }
    var selectedExamType by remember { mutableStateOf(student?.examType ?: ExamType.NAVODAYA) }
    var isActive by remember { mutableStateOf(student?.isActive ?: true) }
    var isDropdownExpanded by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (student == null) "વિદ્યાર્થી બનાવો" else "વિદ્યાર્થી સંપાદન",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                if (errorMessage != null) {
                    Text(
                        text = errorMessage!!,
                        color = TestMitraRed,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }

                Text("નામ", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    placeholder = { Text("નામ દાખલ કરો") },
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text("મોબાઇલ નંબર", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = mobile,
                    onValueChange = { mobile = it },
                    placeholder = { Text("મોબાઇલ નંબર") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text("પાસવર્ડ (પ્રથમ વખત બનાવેલ)", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    placeholder = { Text(if (student != null) "નવો પાસવર્ડ (વૈકલ્પિક)" else "પાસવર્ડ દાખલ કરો") },
                    trailingIcon = {
                        IconButton(onClick = { isPassVisible = !isPassVisible }) {
                            Icon(if (isPassVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility, contentDescription = null)
                        }
                    },
                    visualTransformation = if (isPassVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text("પરીક્ષા પ્રકાર", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Spacer(modifier = Modifier.height(4.dp))

                ExposedDropdownMenuBox(
                    expanded = isDropdownExpanded,
                    onExpandedChange = { isDropdownExpanded = it }
                ) {
                    OutlinedTextField(
                        value = "${selectedExamType.displayNameGujarati} (${selectedExamType.englishName})",
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isDropdownExpanded) },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                    )

                    ExposedDropdownMenu(
                        expanded = isDropdownExpanded,
                        onDismissRequest = { isDropdownExpanded = false }
                    ) {
                        ExamType.entries.forEach { exam ->
                            DropdownMenuItem(
                                text = { Text("${exam.displayNameGujarati} (${exam.englishName})") },
                                onClick = {
                                    selectedExamType = exam
                                    isDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("સ્ટેટસ (Active)", fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Switch(
                        checked = isActive,
                        onCheckedChange = { isActive = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = TestMitraGreen)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isBlank() || mobile.isBlank()) {
                        errorMessage = "નામ અને મોબાઇલ નંબર જરૂરી છે."
                        return@Button
                    }
                    if (student == null && password.isBlank()) {
                        errorMessage = "પાસવર્ડ જરૂરી છે."
                        return@Button
                    }
                    onSave(name, mobile, password, selectedExamType, isActive)
                },
                colors = ButtonDefaults.buttonColors(containerColor = TestMitraGreen),
                modifier = Modifier.testTag("save_student_button")
            ) {
                Text("સેવ કરો")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("રદ કરો")
            }
        }
    )
}

// --- Admin Test Management Screen ---

@Composable
fun AdminTestManagementScreen(
    tests: List<TestItem>,
    selectedExamFilter: ExamType?,
    onExamFilterSelected: (ExamType?) -> Unit,
    onToggleTestStatus: (String, Boolean) -> Unit,
    onSaveTest: (TestItem) -> Unit,
    onDeleteTest: (String) -> Unit,
    onBack: () -> Unit
) {
    var showAddTestDialog by remember { mutableStateOf(false) }
    var editingTest by remember { mutableStateOf<TestItem?>(null) }
    var testToDelete by remember { mutableStateOf<TestItem?>(null) }

    val activeExam = selectedExamFilter ?: ExamType.NAVODAYA
    val filteredTests = tests.filter { it.examType == activeExam }

    if (showAddTestDialog) {
        TestAddEditDialog(
            test = editingTest,
            defaultExamType = activeExam,
            onDismiss = {
                showAddTestDialog = false
                editingTest = null
            },
            onSave = { test ->
                onSaveTest(test)
                showAddTestDialog = false
                editingTest = null
            }
        )
    }

    if (testToDelete != null) {
        AlertDialog(
            onDismissRequest = { testToDelete = null },
            title = { Text("ટેસ્ટ ડિલીટ કરવો છે?", fontWeight = FontWeight.Bold, color = TestMitraRed) },
            text = { Text("આ ટેસ્ટ (${testToDelete?.title}) અને તેના તમામ પ્રશ્નો ડિલીટ થઈ જશે.") },
            confirmButton = {
                Button(
                    onClick = {
                        val id = testToDelete?.id
                        if (id != null) onDeleteTest(id)
                        testToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TestMitraRed)
                ) {
                    Text("ડિલીટ કરો")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { testToDelete = null }) {
                    Text("રદ કરો")
                }
            }
        )
    }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "પાછળ")
                    }
                    Text(
                        text = "ટેસ્ટ મેનેજમેન્ટ",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }

                // Horizontal Exam Type Tabs
                ScrollableTabRow(
                    selectedTabIndex = ExamType.entries.indexOf(activeExam),
                    edgePadding = 16.dp,
                    containerColor = Color.White,
                    contentColor = TestMitraBlue
                ) {
                    ExamType.entries.forEach { exam ->
                        Tab(
                            selected = exam == activeExam,
                            onClick = { onExamFilterSelected(exam) },
                            text = {
                                Text(
                                    text = exam.displayNameGujarati,
                                    fontWeight = if (exam == activeExam) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 14.sp
                                )
                            }
                        )
                    }
                }
            }
        },
        floatingActionButton = {
            Button(
                onClick = {
                    editingTest = null
                    showAddTestDialog = true
                },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = TestMitraBlue),
                modifier = Modifier
                    .padding(16.dp)
                    .testTag("add_new_test_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("+ નવો ટેસ્ટ", fontWeight = FontWeight.Bold)
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(BackgroundLight)
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${activeExam.displayNameGujarati} ટેસ્ટ લિસ્ટ (${filteredTests.size})",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }

            if (filteredTests.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "આ પરીક્ષા પ્રકારમાં હજુ કોઈ ટેસ્ટ ઉમેરાઈ નથી.",
                        color = TextSecondary,
                        fontSize = 15.sp
                    )
                }
            } else {
                LazyColumn(modifier = Modifier.weight(1f)) {
                    items(filteredTests) { test ->
                        AdminTestCard(
                            test = test,
                            onToggleStatus = { isActive ->
                                onToggleTestStatus(test.id, isActive)
                            },
                            onEdit = {
                                editingTest = test
                                showAddTestDialog = true
                            },
                            onDelete = {
                                testToDelete = test
                            }
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun AdminTestCard(
    test: TestItem,
    onToggleStatus: (Boolean) -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, BorderLight),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = test.title,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${test.questions.size} પ્રશ્નો | ${test.durationMinutes} મિનિટ",
                        fontSize = 13.sp,
                        color = TextSecondary
                    )
                }

                // Active / Inactive Toggle Switch (Required feature)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (test.isActive) "Active" else "Inactive",
                        fontSize = 12.sp,
                        color = if (test.isActive) TestMitraGreen else TextSecondary,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(end = 6.dp)
                    )
                    Switch(
                        checked = test.isActive,
                        onCheckedChange = onToggleStatus,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = TestMitraGreen,
                            uncheckedTrackColor = Color(0xFFBDBDBD)
                        ),
                        modifier = Modifier.testTag("toggle_test_${test.id}")
                    )
                }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = BorderLight)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onEdit, modifier = Modifier.size(34.dp)) {
                    Icon(Icons.Default.Edit, contentDescription = "Edit", tint = TestMitraBlue, modifier = Modifier.size(20.dp))
                }
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(onClick = onDelete, modifier = Modifier.size(34.dp)) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = TestMitraRed, modifier = Modifier.size(20.dp))
                }
            }
        }
    }
}

// --- Add / Edit Test Dialog with Questions builder ---

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TestAddEditDialog(
    test: TestItem?,
    defaultExamType: ExamType,
    onDismiss: () -> Unit,
    onSave: (TestItem) -> Unit
) {
    var title by remember { mutableStateOf(test?.title ?: "") }
    var selectedExamType by remember { mutableStateOf(test?.examType ?: defaultExamType) }
    var durationMinutes by remember { mutableIntStateOf(test?.durationMinutes ?: 45) }
    var isActive by remember { mutableStateOf(test?.isActive ?: true) }
    var isDropdownExpanded by remember { mutableStateOf(false) }

    var questionsList by remember {
        mutableStateOf(
            test?.questions ?: listOf(
                QuestionItem(
                    id = UUID.randomUUID().toString(),
                    testId = test?.id ?: "new_test",
                    questionText = "નવો પ્રશ્ન દાખલ કરો...",
                    optionA = "વિકલ્પ A",
                    optionB = "વિકલ્પ B",
                    optionC = "વિકલ્પ C",
                    optionD = "વિકલ્પ D",
                    correctOption = 0,
                    explanation = "સાચા જવાબની સમજૂતી",
                    orderIndex = 1
                )
            )
        )
    }

    var qText by remember { mutableStateOf("") }
    var optA by remember { mutableStateOf("") }
    var optB by remember { mutableStateOf("") }
    var optC by remember { mutableStateOf("") }
    var optD by remember { mutableStateOf("") }
    var correctOpt by remember { mutableIntStateOf(0) }
    var explanation by remember { mutableStateOf("") }
    var showAddQuestionForm by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (test == null) "ટેસ્ટ બનાવો" else "ટેસ્ટ સંપાદન",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                Text("ટેસ્ટ નામ", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    placeholder = { Text("ઉદા. Navodaya Mock Test - 1") },
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text("પરીક્ષા પ્રકાર", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(4.dp))
                ExposedDropdownMenuBox(
                    expanded = isDropdownExpanded,
                    onExpandedChange = { isDropdownExpanded = it }
                ) {
                    OutlinedTextField(
                        value = "${selectedExamType.displayNameGujarati} (${selectedExamType.englishName})",
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isDropdownExpanded) },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                    )
                    ExposedDropdownMenu(
                        expanded = isDropdownExpanded,
                        onDismissRequest = { isDropdownExpanded = false }
                    ) {
                        ExamType.entries.forEach { exam ->
                            DropdownMenuItem(
                                text = { Text("${exam.displayNameGujarati} (${exam.englishName})") },
                                onClick = {
                                    selectedExamType = exam
                                    isDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text("સમય (મિનિટ)", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = durationMinutes.toString(),
                    onValueChange = { durationMinutes = it.toIntOrNull() ?: 30 },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("સ્ટેટસ (Active)", fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Switch(
                        checked = isActive,
                        onCheckedChange = { isActive = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = TestMitraGreen)
                    )
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = BorderLight)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("પ્રશ્નો (${questionsList.size})", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Button(
                        onClick = { showAddQuestionForm = !showAddQuestionForm },
                        colors = ButtonDefaults.buttonColors(containerColor = TestMitraBlue),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(if (showAddQuestionForm) "બંધ કરો" else "+ પ્રશ્ન ઉમેરો", fontSize = 12.sp)
                    }
                }

                if (showAddQuestionForm) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Card(
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F5F9)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            OutlinedTextField(
                                value = qText,
                                onValueChange = { qText = it },
                                placeholder = { Text("પ્રશ્ન લખાણ") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedTextField(value = optA, onValueChange = { optA = it }, placeholder = { Text("વિકલ્પ A") }, modifier = Modifier.fillMaxWidth())
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedTextField(value = optB, onValueChange = { optB = it }, placeholder = { Text("વિકલ્પ B") }, modifier = Modifier.fillMaxWidth())
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedTextField(value = optC, onValueChange = { optC = it }, placeholder = { Text("વિકલ્પ C") }, modifier = Modifier.fillMaxWidth())
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedTextField(value = optD, onValueChange = { optD = it }, placeholder = { Text("વિકલ્પ D") }, modifier = Modifier.fillMaxWidth())
                            Spacer(modifier = Modifier.height(6.dp))

                            Text("સાચો વિકલ્પ પસંદ કરો:", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            Row {
                                listOf("A", "B", "C", "D").forEachIndexed { idx, label ->
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        RadioButton(
                                            selected = correctOpt == idx,
                                            onClick = { correctOpt = idx },
                                            colors = RadioButtonDefaults.colors(selectedColor = TestMitraGreen)
                                        )
                                        Text(label, fontSize = 14.sp)
                                    }
                                }
                            }

                            OutlinedTextField(
                                value = explanation,
                                onValueChange = { explanation = it },
                                placeholder = { Text("સમજૂતી (Explanation)") },
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Button(
                                onClick = {
                                    if (qText.isNotBlank() && optA.isNotBlank() && optB.isNotBlank()) {
                                        val newQ = QuestionItem(
                                            id = UUID.randomUUID().toString(),
                                            testId = test?.id ?: "new_test",
                                            questionText = qText,
                                            optionA = optA,
                                            optionB = optB,
                                            optionC = if (optC.isBlank()) "None" else optC,
                                            optionD = if (optD.isBlank()) "None" else optD,
                                            correctOption = correctOpt,
                                            explanation = explanation,
                                            orderIndex = questionsList.size + 1
                                        )
                                        questionsList = questionsList + newQ
                                        qText = ""
                                        optA = ""
                                        optB = ""
                                        optC = ""
                                        optD = ""
                                        explanation = ""
                                        showAddQuestionForm = false
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = TestMitraGreen),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("પ્રશ્ન સાચવો")
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        val newTest = TestItem(
                            id = test?.id ?: UUID.randomUUID().toString(),
                            examType = selectedExamType,
                            title = title,
                            durationMinutes = durationMinutes,
                            isActive = isActive,
                            questions = questionsList,
                            createdAt = test?.createdAt ?: "2026-08-13"
                        )
                        onSave(newTest)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = TestMitraGreen),
                modifier = Modifier.testTag("save_test_button")
            ) {
                Text("સેવ કરો")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("રદ કરો")
            }
        }
    )
}

// --- Admin Exam Type Management Screen ---

@Composable
fun AdminExamTypeManagementScreen(
    tests: List<TestItem>,
    students: List<UserProfile>,
    onSelectExam: (ExamType) -> Unit,
    onBack: () -> Unit
) {
    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "પાછળ")
                }
                Text(
                    text = "પરીક્ષા પ્રકાર મેનેજમેન્ટ",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(BackgroundLight)
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            item {
                Text(
                    text = "ઉપલબ્ધ તમામ પરીક્ષા વિભાગો",
                    fontSize = 15.sp,
                    color = TextSecondary,
                    modifier = Modifier.padding(bottom = 12.dp)
                )
            }

            items(ExamType.entries) { exam ->
                val examTests = tests.filter { it.examType == exam }
                val examStudents = students.filter { it.examType == exam }
                val examColor = getExamColor(exam)

                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, BorderLight),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp)
                        .clickable { onSelectExam(exam) }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(examColor),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Quiz,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(26.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(14.dp))

                            Column {
                                Text(
                                    text = "${exam.displayNameGujarati} (${exam.englishName})",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "${examTests.size} ટેસ્ટ ઉપલબ્ધ | ${examStudents.size} વિદ્યાર્થીઓ",
                                    fontSize = 13.sp,
                                    color = TextSecondary
                                )
                            }
                        }

                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Manage",
                            tint = TestMitraGreen,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

// --- Admin Announcement Management Screen ---

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminAnnouncementManagementScreen(
    announcements: List<AnnouncementItem>,
    selectedExamFilter: ExamType?,
    onExamFilterSelected: (ExamType?) -> Unit,
    onSaveAnnouncement: (AnnouncementItem) -> Unit,
    onDeleteAnnouncement: (String) -> Unit,
    onBack: () -> Unit
) {
    var showDialog by remember { mutableStateOf(false) }
    var editingAnn by remember { mutableStateOf<AnnouncementItem?>(null) }
    var title by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var examType by remember { mutableStateOf(selectedExamFilter ?: ExamType.NAVODAYA) }
    var isImportant by remember { mutableStateOf(false) }
    var isDropdownOpen by remember { mutableStateOf(false) }

    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text(if (editingAnn == null) "નવી સૂચના બનાવો" else "સૂચના સંપાદન", fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Text("શીર્ષક", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(value = title, onValueChange = { title = it }, placeholder = { Text("સૂચના શીર્ષક") }, modifier = Modifier.fillMaxWidth())

                    Spacer(modifier = Modifier.height(12.dp))

                    Text("સંદેશ (Message)", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(value = message, onValueChange = { message = it }, placeholder = { Text("સૂચનાની વિગત") }, maxLines = 4, modifier = Modifier.fillMaxWidth())

                    Spacer(modifier = Modifier.height(12.dp))

                    Text("પરીક્ષા પ્રકાર", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(4.dp))
                    ExposedDropdownMenuBox(
                        expanded = isDropdownOpen,
                        onExpandedChange = { isDropdownOpen = it }
                    ) {
                        OutlinedTextField(
                            value = "${examType.displayNameGujarati} (${examType.englishName})",
                            onValueChange = {},
                            readOnly = true,
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isDropdownOpen) },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                        )
                        ExposedDropdownMenu(
                            expanded = isDropdownOpen,
                            onDismissRequest = { isDropdownOpen = false }
                        ) {
                            ExamType.entries.forEach { exam ->
                                DropdownMenuItem(
                                    text = { Text("${exam.displayNameGujarati} (${exam.englishName})") },
                                    onClick = {
                                        examType = exam
                                        isDropdownOpen = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("મહત્વપૂર્ણ સૂચના (Important)", fontSize = 14.sp)
                        Switch(
                            checked = isImportant,
                            onCheckedChange = { isImportant = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = TestMitraRed)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (title.isNotBlank() && message.isNotBlank()) {
                            val newItem = AnnouncementItem(
                                id = editingAnn?.id ?: UUID.randomUUID().toString(),
                                title = title,
                                message = message,
                                examType = examType,
                                date = "13/08/2026",
                                isActive = true,
                                isImportant = isImportant
                            )
                            onSaveAnnouncement(newItem)
                            showDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TestMitraGreen)
                ) {
                    Text("સેવ કરો")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showDialog = false }) {
                    Text("રદ કરો")
                }
            }
        )
    }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "પાછળ")
                }
                Text(
                    text = "સૂચનાઓ મેનેજમેન્ટ",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }
        },
        floatingActionButton = {
            Button(
                onClick = {
                    editingAnn = null
                    title = ""
                    message = ""
                    isImportant = false
                    showDialog = true
                },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = TestMitraBlue),
                modifier = Modifier
                    .padding(16.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("+ નવી સૂચના", fontWeight = FontWeight.Bold)
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(BackgroundLight)
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            if (announcements.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = "કોઈ સૂચનાઓ ઉપલબ્ધ નથી.", color = TextSecondary)
                    }
                }
            } else {
                items(announcements) { ann ->
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(1.dp, BorderLight),
                        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(getExamColor(ann.examType).copy(alpha = 0.12f))
                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                ) {
                                    Text(
                                        text = "${ann.examType.displayNameGujarati} (${ann.date})",
                                        color = getExamColor(ann.examType),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                Row {
                                    IconButton(
                                        onClick = {
                                            editingAnn = ann
                                            title = ann.title
                                            message = ann.message
                                            examType = ann.examType
                                            isImportant = ann.isImportant
                                            showDialog = true
                                        },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(Icons.Default.Edit, contentDescription = "Edit", tint = TestMitraBlue, modifier = Modifier.size(18.dp))
                                    }
                                    IconButton(
                                        onClick = { onDeleteAnnouncement(ann.id) },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = TestMitraRed, modifier = Modifier.size(18.dp))
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = ann.title,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            Text(
                                text = ann.message,
                                fontSize = 14.sp,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }
        }
    }
}

// --- Admin Profile Screen ---

@Composable
fun AdminProfileScreen(
    adminUser: UserProfile?,
    onLogout: () -> Unit,
    onBack: () -> Unit
) {
    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "પાછળ")
                }
                Text(
                    text = "એડમિન પ્રોફાઇલ",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(BackgroundLight)
                .padding(innerPadding)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(20.dp))

            Box(
                modifier = Modifier
                    .size(90.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFE3F2FD)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = null,
                    tint = TestMitraBlue,
                    modifier = Modifier.size(50.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = adminUser?.fullName ?: "Super Admin",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )

            Text(
                text = "રોલ: એડમિનિસ્ટ્રેટર",
                fontSize = 14.sp,
                color = TestMitraBlue,
                fontWeight = FontWeight.SemiBold
            )

            Spacer(modifier = Modifier.height(24.dp))

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    ProfileInfoRow(label = "એડમિન ID", value = adminUser?.id ?: "admin-1")
                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = BorderLight)
                    ProfileInfoRow(label = "મોબાઇલ નંબર", value = adminUser?.mobile ?: "9999999999")
                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = BorderLight)
                    ProfileInfoRow(label = "બેકએન્ડ સિન્ક્રોનાઇઝેશન", value = "Supabase Active")
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            Button(
                onClick = onLogout,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFFFEBEE),
                    contentColor = TestMitraRed
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
            ) {
                Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = null, tint = TestMitraRed)
                Spacer(modifier = Modifier.width(8.dp))
                Text("લૉગઆઉટ કરો", fontWeight = FontWeight.Bold, color = TestMitraRed)
            }
        }
    }
}
