package com.example.model

enum class ExamType(val id: String, val displayNameGujarati: String, val englishName: String) {
    NAVODAYA("Navodaya", "નવોદય", "Navodaya"),
    NMMS("NMMS", "એનએમએમએસ", "NMMS"),
    GYAN_SETU("Gyan Setu", "જ્ઞાન સેતુ", "Gyan Setu"),
    GYAN_SADHANA("Gyan Sadhana", "જ્ઞાન સાધના", "Gyan Sadhana"),
    TET_1("TET_1", "ટેટ ૧", "TET_1");

    companion object {
        fun fromString(value: String?): ExamType {
            if (value == null) return NAVODAYA
            return entries.firstOrNull { 
                it.id.equals(value, ignoreCase = true) || 
                it.name.equals(value, ignoreCase = true) ||
                it.englishName.equals(value, ignoreCase = true)
            } ?: NAVODAYA
        }
    }
}

enum class UserRole {
    ADMIN,
    STUDENT;

    companion object {
        fun fromString(value: String?): UserRole {
            if (value == null) return STUDENT
            return if (value.equals("admin", ignoreCase = true) || value.equals("ADMIN", ignoreCase = true)) {
                ADMIN
            } else {
                STUDENT
            }
        }
    }
}

data class UserProfile(
    val id: String,
    val mobile: String,
    val passwordHash: String,
    val fullName: String,
    val role: UserRole,
    val examType: ExamType?, // null for admin
    val isActive: Boolean = true,
    val sessionToken: String? = null,
    val createdAt: String = ""
)

data class QuestionItem(
    val id: String,
    val testId: String,
    val questionText: String,
    val optionA: String,
    val optionB: String,
    val optionC: String,
    val optionD: String,
    val correctOption: Int, // 0 for A, 1 for B, 2 for C, 3 for D
    val explanation: String = "",
    val orderIndex: Int = 0
) {
    fun getOption(index: Int): String {
        return when (index) {
            0 -> optionA
            1 -> optionB
            2 -> optionC
            3 -> optionD
            else -> ""
        }
    }

    fun getCorrectOptionText(): String {
        return getOption(correctOption)
    }
}

data class TestItem(
    val id: String,
    val examType: ExamType,
    val title: String,
    val durationMinutes: Int = 30,
    val isActive: Boolean = true,
    val questions: List<QuestionItem> = emptyList(),
    val createdAt: String = ""
) {
    val totalQuestions: Int
        get() = questions.size
}

data class AnnouncementItem(
    val id: String,
    val title: String,
    val message: String,
    val examType: ExamType, // Announcements are filtered by exam type
    val date: String,
    val isActive: Boolean = true,
    val isImportant: Boolean = false
)

data class TestAttemptState(
    val test: TestItem,
    val currentQuestionIndex: Int = 0,
    val selectedAnswers: MutableMap<Int, Int> = mutableMapOf(), // questionIndex -> selectedOption
    val answeredConfirmed: MutableMap<Int, Boolean> = mutableMapOf(), // questionIndex -> submitted
    val timeRemainingSeconds: Int = 0,
    val isCompleted: Boolean = false
) {
    val correctCount: Int
        get() = selectedAnswers.count { (index, selected) ->
            index < test.questions.size && test.questions[index].correctOption == selected
        }

    val wrongCount: Int
        get() = selectedAnswers.count { (index, selected) ->
            index < test.questions.size && test.questions[index].correctOption != selected
        }

    val totalScore: Int
        get() = correctCount

    val percentage: Int
        get() = if (test.questions.isNotEmpty()) (correctCount * 100) / test.questions.size else 0
}
