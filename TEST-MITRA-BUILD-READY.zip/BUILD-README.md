# TEST MITRA - APK BUILD READY

This package is prepared for GitHub Actions APK building.

## Build
1. Upload/extract this project into your GitHub repository.
2. Open Actions.
3. Select "Build TEST MITRA APK".
4. Run workflow.
5. Download the artifact named `TEST-MITRA-debug-apk`.

## Important
This package uses the application's existing source/configuration. The workflow builds a debug APK without requiring a release keystore.
If the app source itself requires Supabase URL/key values, configure them using the project's existing environment/config mechanism.
